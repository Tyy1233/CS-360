package com.example.project;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
//extend to the Base Adpter
public class ItemsList  {
    //set up array and private variables
    private final Activity context;
    private PopupWindow popwindow;
    ArrayList<Item> items;
    ItemsSQLiteHandler db;
    //public items
    public ItemsList(Activity context, ArrayList<Item> items, ItemsSQLiteHandler db) {
        this.context = context;
        this.items = items;
        this.db = db;
    }
    //setting up view holder
    public static class ViewHolder {
        TextView textViewItemId;
        TextView textViewUserEmail;
        TextView textViewItemDesc;
        TextView textViewItemQty;
        TextView textViewItemUnit;
        ImageButton editBtn;
        ImageButton deleteBtn;
    }
    //getting settings for view


}
