package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
//creates class that extents to activity items
public class items extends AppCompatActivity {


    //create all the variables needed for the code
    TextView UserName, TotalItems;
    ImageButton AddItemButton, SmsButton, DelAllItemsButton;
    ListView ItemsListView;
    ItemsSQLiteHandler db;
    static String NameHolder, EmailHolder, PhoneNumHolder;
    AlertDialog AlertDialog = null;
    ArrayList<Item> items;
    ItemsList customItemsList;
    int itemsCount;
    //setting up public and private variables
    public static final String UserEmail = "";
    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static boolean smsAuthorized = false;
    private static boolean deleteItems = false;
    //oncreate for the connecting activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);



    }
}
