package com.example.sayhello3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




    }

    public void saySomething(View view) {
        final TextView outputText = (TextView) findViewById(R.id.textView);
        final EditText nameText = (EditText) findViewById(R.id.editText);
        Button button = (Button) findViewById(R.id.button);

        TextWatcher textWatcher = new TextWatcher(){
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after){

            }
          @Override
          public void onTextChanged(CharSequence s , int start, int count, int after){
              String outputText = nameText.getText().toString().trim();
              button.setEnabled(!outputText.isEmpty());
          }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nameText.getText().equals("Enter Name")) {
                    outputText.setText("Oops you forgot to enter your name");
                }
                else{
                    outputText.setText("Hello " +nameText.getText());
            }
        }
    });
}
}